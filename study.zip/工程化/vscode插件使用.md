# 插件一般用法
- ctrl + Shift + p或者按f1调出命令行后
- 在>号后面输入插件名字即可调用插件

## Quokka 是一个调试工具，可以为您正在编写的代码提供实时反馈。它能够预览变量的函数和计算值结果。

## vscode-faker
> 可以随机生成姓名、地址、图像、电话号码，或者经典的乱数假文段落，并且每个类别还包含了各种子类别，你可以根据自身的需求来使用这些数据。

## TODO Highlight--
> 这个插件能够在你的代码中标记出所有的 TODO 注释，以便更容易追踪任何未完成的业务。
- 添加todo标签//TODO:(注意有冒号)及注解。比如这样
>> //TODO:这里有个bug，但是空间太小了，我的算法写不下。
- 按F1，输入todo命令，列出所有todo高亮标签。

## Css Peek
> 在你的html中鼠标指向某个class或者id名称按住Ctrl键+鼠标左键可以直接定位到该名称的CSS的位置

## Turbo Console Log
```
ctrl + alt + l 选中变量之后，使用这个快捷键生成 console.log

alt + shift + c 注释所有 console.log

alt + shift + u 启用所有 console.log

alt + shift + d 删除所有 console.log
```

## vscode-json
> 在json文件中右鍵使用format Document或format Document with即可美化json

## Settings Sync，
> 在不同电脑间同步你的插件，具体流程百度
- f1后输入Sync，点击upload，后登录到GitHub，回到vscode继续upload，成功后调试版OUTPUT有信息显示
- 下载时同样输入Sync，有个download

## PolaCode 生成漂亮的代码截图
## CodeIf，CodeIf 是一个用来给变量命名的网站，

## css Bomb 梳理 CSS 属性顺序, 具体使用可百度

## REST Client 快速浏览接口数据
> 新建一个.http文件 输入GET api地址即可出现Send Request，点击后看到效果
