# css的笔记
## 这是一些自己总结或者从书籍中整理的css知识
- css reset库的一个cdn地址
```
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css" />
```
- 代码书写规范  http://alloyteam.github.io/CodeGuide/
- css常见属性调试和demo示例  https://qishaoxuan.github.io/css_tricks/accordion/
